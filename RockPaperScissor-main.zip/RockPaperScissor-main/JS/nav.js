import anime from './anime.es.js';

export default function animation(h){
    console.log('hi')
    anime({
        targets: '.menu',
        translateY: '',
        rotate: '0turn',
        backgroundColor: '',   
        scale:'1',
        duration: 4000
    });
    
}